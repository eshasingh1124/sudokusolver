# Sudoku Solver
Sudoku Solving web app made using backtracking algorithm. 
Made by Priyanshu Modi.
